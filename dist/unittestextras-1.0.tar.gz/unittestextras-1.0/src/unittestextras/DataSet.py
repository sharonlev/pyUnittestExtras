__author__ = 'Sharon Lev'
__email__ = 'slev@apple.com'
__date__ = '11/12/16'

def DataSet(*args):
  return lambda: args